"""dailyfresh URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.contrib.auth.decorators import login_required
from django.urls import path, include, re_path

from apps.user import views
from apps.user.views import RegisterView, ActiveView, LoginView, UserInfoView, AddressView, UserOrderView, LogoutView

urlpatterns = [
    re_path(r'^register$', RegisterView.as_view(), name='register'),
    re_path(r'^active/(?P<token>.*)$', ActiveView.as_view(), name='active'),
    re_path(r'^login$', LoginView.as_view(), name='login'),
    re_path(r'^logout$', LogoutView.as_view(), name='logout'),
    # re_path(r'^$', login_required(UserInfoView.as_view()), name='user'),
    # re_path(r'^address$', login_required(AddressView.as_view()), name='address'),
    # re_path(r'^order$', login_required(UserOrderView.as_view()), name='order'),
    re_path(r'^$', UserInfoView.as_view(), name='user'),
    re_path(r'^address$', AddressView.as_view(), name='address'),
    re_path(r'^order/(?P<page>\d+)$', UserOrderView.as_view(), name='order'),
]
