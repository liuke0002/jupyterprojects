import time
import traceback
from datetime import datetime

from alipay.aop.api.AlipayClientConfig import AlipayClientConfig
from alipay.aop.api.DefaultAlipayClient import DefaultAlipayClient
from alipay.aop.api.domain.AlipayTradeCreateModel import AlipayTradeCreateModel
from alipay.aop.api.domain.AlipayTradePagePayModel import AlipayTradePagePayModel
from alipay.aop.api.domain.AlipayTradeQueryModel import AlipayTradeQueryModel
from alipay.aop.api.request.AlipayTradeCreateRequest import AlipayTradeCreateRequest
from alipay.aop.api.request.AlipayTradePagePayRequest import AlipayTradePagePayRequest
from alipay.aop.api.request.AlipayTradeQueryRequest import AlipayTradeQueryRequest
from alipay.aop.api.response.AlipayTradeCreateResponse import AlipayTradeCreateResponse
from alipay.aop.api.response.AlipayTradeQueryResponse import AlipayTradeQueryResponse
from django.http import JsonResponse
from django.shortcuts import render, redirect

# Create your views here.
from django.urls import reverse
from django.views import View
from django_redis import get_redis_connection

from apps.goods.models import GoodsSKU
from apps.order.models import OrderInfo, OrderGoods
from apps.user.models import Address
from utils.mixin import LoginRequiredMixin
from django.db import transaction


class OrderPlaceView(LoginRequiredMixin, View):
    '''提交订单页面展示'''

    @transaction.atomic
    def post(self, request):
        sku_ids = request.POST.getlist('sku_ids')
        user = request.user
        if not sku_ids:
            # 跳转到购物车页面
            return redirect(reverse('cart:show'))

        conn = get_redis_connection('default')
        cart_key = 'cart_%d' % user.id

        skus = []
        total_count = 0
        total_price = 0
        for sku_id in sku_ids:
            # 根据商品id获取商品信息
            sku = GoodsSKU.objects.get(id=sku_id)
            count = conn.hget(cart_key, sku_id)

            amount = sku.price * int(count)

            sku.amount = amount
            sku.count = int(count)

            skus.append(sku)

            total_count += int(count)
            total_price += amount

        # 运费
        transit_price = 10

        total_pay = total_price + transit_price

        addrs = Address.objects.filter(user=user)

        sku_ids = ','.join(sku_ids)

        context = {'skus': skus,
                   'total_count': total_count,
                   'total_price': total_price,
                   'total_pay': total_pay,
                   'transit_price': transit_price,
                   'addrs': addrs,
                   'sku_ids': sku_ids}

        return render(request, 'place_order.html', context)


class OrderCommitView(View):
    '''订单创建'''

    def post(self, request):
        user = request.user
        if not user.is_authenticated:
            return JsonResponse({'res': 0, 'errmsg': '请先登录'})

        addr_id = request.POST.get('addr_id')
        pay_style = request.POST.get('pay_style')
        sku_ids = request.POST.get('sku_ids')

        if not all([addr_id, pay_style, sku_ids]):
            return JsonResponse({'res': 1, 'errmsg': '参数不完整'})

        if pay_style not in OrderInfo.PAY_METHODS.keys():
            return JsonResponse({'res': 2, 'errmsg': '非法的支付方式'})

        try:
            addr = Address.objects.get(id=addr_id)
        except Address.DoesNotExist:
            return JsonResponse({'res': 3, 'errmsg': '订单地址不存在'})

        order_id = datetime.now().strftime('%Y%m%d%H%M%S') + str(user.id)
        transit_price = 10

        conn = get_redis_connection('default')
        cart_key = 'cart_%d' % user.id

        total_count = 0
        total_price = 0

        sku_ids = sku_ids.split(',')

        # 运费
        transit_price = 10

        total_pay = total_price + transit_price

        save_id = transaction.savepoint()
        try:
            order = OrderInfo.objects.create(order_id=order_id,
                                             user=user,
                                             addr=addr,
                                             pay_method=pay_style,
                                             total_count=total_count,
                                             total_price=total_price,
                                             transit_price=transit_price)

            for sku_id in sku_ids:
                # 根据商品id获取商品信息
                with transaction.atomic():
                    try:
                        sku = GoodsSKU.objects.select_for_update().get(id=sku_id)
                    except GoodsSKU.DoesNotExist:
                        transaction.savepoint_rollback(save_id)
                        return JsonResponse({'res': 3, 'errmsg': '商品不存在'})
                    count = conn.hget(cart_key, sku_id)

                    # 判断商品库存
                    if int(count) > sku.stock:
                        transaction.savepoint_rollback(save_id)
                        return JsonResponse({'res': 6, 'errmsg': '商品库存不足'})
                    amount = sku.price * int(count)

                    total_count += int(count)
                    total_price += amount

                    OrderGoods.objects.create(order=order,
                                              sku=sku,
                                              count=count,
                                              price=sku.price)

                    # 更新库存
                    sku.stock -= int(count)
                    sku.sales += int(count)
                    sku.save()

            order.total_count = total_count
            order.total_price = total_price
            order.save()
        except Exception as e:
            print(e)
            transaction.savepoint_rollback(save_id)
            return JsonResponse({'res': 7, 'errmsg': '下单失败'})

        transaction.savepoint_commit(save_id)
        conn.hdel(cart_key, *sku_ids)

        return JsonResponse({'res': 5, 'message': '创建成功'})


class OrderPayView(View):
    '''订单支付'''

    """支付宝支付"""

    @staticmethod
    def sign():
        # 构造签名基础参数
        alipay_client_config = AlipayClientConfig(sandbox_debug=True)
        alipay_client_config.app_id = '2016101500689857'
        alipay_client_config.app_private_key = 'MIIEpAIBAAKCAQEA0aSeZLA4A7KIQlbvcSuKWFNzDw0/ihYvOlHPS9YIe0QC7RqUedpg4lK0mY6CDUKddP9fV6EWWrtzXLmR4XO1N0YMG7SrKCxnlqKWLX2GkFXqn1M4fk0fFiBo4DW0UJaJS8fj6HH1qfzHhqhjOXtALv/ReLO24lbv+de3hEyamAVU9Dusa4syxCLYqO62LHMn/1bQho9BHQXMqDIgaz07OJiHAdpl8YZ7Y2RgqG2JmIZdvubPyM96tZAvZVbixZ84w71RGRecPLlRSPbqXL15B+aVUtX6nXdrm2cTBKMP2ndSuh3h4O7dsfZXilvEc0S7d8AtZL+ZfMdXmALCy4gquQIDAQABAoIBAQDIHRlNB6EQdnT2zkFVh7hRQ6cK8Rx71V1TkBAOVcpWz77zUXH1Nu1QXJ4kDhI6UiI3MiVyYkQSa+hc1I5Z5LdQgb7BG55dhLWE5sHvvmiakkiZuTit5zQLTPiPPPRYELoR6ka09UMI9lAHS+kbT3ke4/ax/upN96qulKmK0gynmoUD+xHuQHGpGfmickRKwaFYZGiTGoUsEMLb5xeqcM2yyswKVBukp22AiWDK0i4vDGZC7NslzFbs1vOtY+RMO9eUGw0OWEQZ6A5iN7qEhcsEmFrWyxnfX4DDSqjlOVuFd99m0BUHeuyNPikKwhTp/OB5tgYvwXuhaWi3BJjIjVUBAoGBAOqV5TLkN8tzpeyItlVVhSHic/+T0Vyb5X4ewsePuZIg5W4Bsp4JAlPen+OOUMpvZi+P++aSKguHWD+gw2uIbCo55fUouIQyZLAVurajKvNEgU+D32pC1sTtqiIQ0KqEGtUyFLLNMJDQvF5d/xFd/Ak+8xJphaHVvlZQ52AH04SJAoGBAOTH1ZyTtyfMDr/DwNNeMZoiybgHWHp/YhjxUd5fIDP7zAQJJkI6sQMwLZh2LtBTlYG1OBkKWrUtS06VMsKXpQzJhYKlPcxEt60ZYVLRAMbJaehJ6u5dx/XRkEUc9r1fpRc1CCD19/ver7aIOCIJ8PUcUUJoEnrrIiOHGokSK0ixAoGAaylCZHcgjc4ss9rYAC9q+8mo1828zCNjOLPwop0jVn+0jwYzhEH1UD7Yp2jxuygcdAnANtn6Xv3a8GYOH2dYkgmU5ONPNwSWPmIOwzPSgQKAV8SUIMSbu6YeHCW2TM7AOzf/gJZ/YwgXpLwnstVONyMMgxK1OvKbWm7m41Vv6JECgYBTSdkflrtgNq7L64UgrjMarT2IzMvOVN+uuvQWI8WCh1G/ymDuTZWx1nFTBvuGBlfwj7vridR6DxJSeoivRSvmWttLM8MqwX2o/Attbf99X0g6M+befq/Uc0W1k5TUXqSorTrXXRS50llf93mQEtRxN6zxoxfPPhkAnCfx7PZrEQKBgQDQv4KrOSzIBd98PvA6ukG65kSIOeWnv+ucCKHB4c26slOtwz+5s+l7L2h5oONHpQoj/KSYpkS4pyk+SjEKgCZOPZzC4ki43WRIyz6EMV8lOSbaYofLaFduaC2bPYiqusQL7VwJxdSpCxtKC30TjR8jsbvL4mdq+bUtSLR0MaHRoQ=='
        alipay_client_config.alipay_public_key = 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAkw0MAVsPByPYjvaxIqQs9IYI4QgLQ33wQQ79zHgpFnd6kMf9xMHGp6Fyo8pv7sw3dvrYlPvr8vzWlTKVCjeNeAEzKTNMTpYzVHTu9Ja1vYsXhmta9Omvaq0ZO5AcoDs5HEePY9M++1h/6P/9NJl76pT4sea28EsYSp10w9mHKVsYebmMmdj4FDecx1VpvakLBlrVspcCFDqr0D+reflAFj4kphLEzUuHmMwokr+RHoCr6OPgS8BMxtWHsDA60Sxr/sgBVXaREn6sxZDZVBfclxyDU//4YRUYDT+0ignMvIQAbu5rN4PWRBtxSXDhlSoCadERHthqVAQ1BL9kMuA5+QIDAQAB'
        client = DefaultAlipayClient(alipay_client_config)
        return client

    def post(self, request):
        '''订单支付'''
        # 用户是否登录
        user = request.user
        if not user.is_authenticated:
            return JsonResponse({'res': 0, 'errmsg': '用户未登录'})

        # 接收参数
        order_id = request.POST.get('order_id')
        print(order_id)
        # 校验参数
        if not order_id:
            return JsonResponse({'res': 1, 'errmsg': '无效订单id'})

        try:
            order = OrderInfo.objects.get(order_id=order_id,
                                          user=user,
                                          pay_method=3,
                                          order_status=1)
        except OrderInfo.DoesNotExist:
            print('hahahha')
            return JsonResponse({'res': 2, 'errmsg': '订单错误'})

        # 业务处理：使用python-alipay调用支付宝的支付接口
        client = OrderPayView.sign()

        total_pay = order.total_price + order.transit_price
        model = AlipayTradePagePayModel()
        model.out_trade_no = order_id
        model.product_code = 'FAST_INSTANT_TRADE_PAY'
        model.total_amount = str(total_pay)
        model.subject = "天天生鲜-%s" % order_id
        model.timeout_express = '10m'

        pay_request = AlipayTradePagePayRequest(biz_model=model)

        pay_url = client.page_execute(pay_request, http_method='GET')

        return JsonResponse({'res': 3, 'msg': '正在支付中...', 'url': pay_url})


class OrderCheckView(LoginRequiredMixin, View):
    '''支付宝结果用户查询'''

    def post(self, request):

        user = request.user
        if not user.is_authenticated:
            return JsonResponse({'res': 0, 'errmsg': '用户未登录'})

        # 接收参数
        order_id = request.POST.get('order_id')
        # 校验参数
        if not order_id:
            return JsonResponse({'res': 1, 'errmsg': '无效订单id'})

        try:
            order = OrderInfo.objects.get(order_id=order_id,
                                          user=user,
                                          pay_method=3,
                                          order_status=1)
        except OrderInfo.DoesNotExist:
            print('hahahha')
            return JsonResponse({'res': 2, 'errmsg': '订单错误'})

        while True:
            # 检测订单状态
            if order.order_status > 1:
                print('支付宝内部修改成功!')
                return JsonResponse({'res': 0, 'msg': '支付成功!'})
            # 发送查询请求
            client = OrderPayView.sign()

            # 构造请求对象
            model = AlipayTradeQueryModel()
            model.out_trade_no = order_id
            req = AlipayTradeQueryRequest(biz_model=model)

            # 执行请求操作
            try:
                response_content = client.execute(req)
            except Exception as e:
                return JsonResponse({'res': -1, 'msg': e})
            if response_content:
                # 解析响应结果
                response = AlipayTradeQueryResponse()
                response.parse_response_content(response_content)
                # 响应成功的业务处理
                if response.is_success():
                    # 成功
                    if response.trade_status == 'TRADE_SUCCESS':
                        trade_no = response.trade_no
                        order.trade_no = trade_no
                        order.order_status = 4
                        order.save()
                        return JsonResponse({'res': 0, 'msg': '支付成功!'})
                    # 等待付款
                    elif response.trade_status == 'WAIT_BUYER_PAY':
                        time.sleep(5)
                        continue
                    else:
                        return JsonResponse({'res': -1, 'msg': '支付失败'})
                elif response.code == '40004':
                    time.sleep(5)
                    continue
                else:
                    return JsonResponse({'res': -2, 'msg': '支付失败'})


class CommentView(LoginRequiredMixin, View):
    """订单评论"""

    def get(self, request, order_id):
        """提供评论页面"""
        user = request.user

        # 校验数据
        if not order_id:
            return redirect(reverse('user:order'))

        try:
            order = OrderInfo.objects.get(order_id=order_id, user=user)
        except OrderInfo.DoesNotExist:
            return redirect(reverse("user:order"))

        # 根据订单的状态获取订单的状态标题
        order.status_name = OrderInfo.ORDER_STATUS[order.order_status]

        # 获取订单商品信息
        order_skus = OrderGoods.objects.filter(order_id=order_id)
        for order_sku in order_skus:
            # 计算商品的小计
            amount = order_sku.count * order_sku.price
            # 动态给order_sku增加属性amount,保存商品小计
            order_sku.amount = amount
        # 动态给order增加属性order_skus, 保存订单商品信息
        order.order_skus = order_skus

        # 使用模板
        return render(request, "order_comment.html", {"order": order})

    def post(self, request, order_id):
        """处理评论内容"""
        user = request.user
        # 校验数据
        if not order_id:
            return redirect(reverse('user:order'))

        try:
            order = OrderInfo.objects.get(order_id=order_id, user=user)
        except OrderInfo.DoesNotExist:
            return redirect(reverse("user:order"))

        # 获取评论条数
        total_count = request.POST.get("total_count")
        total_count = int(total_count)

        # 循环获取订单中商品的评论内容
        for i in range(1, total_count + 1):
            # 获取评论的商品的id
            sku_id = request.POST.get("sku_%d" % i)  # sku_1 sku_2
            # 获取评论的商品的内容
            content = request.POST.get('content_%d' % i, '')  # cotent_1 content_2 content_3
            try:
                order_goods = OrderGoods.objects.get(order=order, sku_id=sku_id)
            except OrderGoods.DoesNotExist:
                continue

            order_goods.comment = content
            order_goods.save()

        order.order_status = 5  # 已完成
        order.save()

        return redirect(reverse("user:order", kwargs={"page": 1}))
