from django.http import JsonResponse
from django.shortcuts import render, redirect

# Create your views here.
from django.urls import reverse
from django.views import View
from django_redis import get_redis_connection

from apps.goods.models import GoodsSKU
from utils.mixin import LoginRequiredMixin


class CartAddView(View):
    '''購物車記錄添加'''

    def post(self, request):
        '''購物車記錄添加'''
        user = request.user
        if not user.is_authenticated:
            return JsonResponse({'res': 0, 'errmsg': '請先登錄'})
            # return redirect(reverse('user:login'))
        # 1.接收數據
        sku_id = request.POST.get('sku_id')
        count = request.POST.get('count')

        # 2.數據校驗
        if not all([sku_id, count]):
            return JsonResponse({'res': 1, 'errmsg': '數據不完整'})

        try:
            count = int(count)
        except Exception as e:
            return JsonResponse({'res': 2, 'errmsg': '商品數目出錯'})

        try:
            sku = GoodsSKU.objects.get(id=sku_id)
        except GoodsSKU.DoesNotExist:
            return JsonResponse({'res': 3, 'errmsg': '商品不存在'})
        # 3.業務處理

        conn = get_redis_connection('default')
        cart_key = 'cart_%d' % user.id
        # 如果sku_id不存在，hget返回None
        cart_count = conn.hget(cart_key, sku_id)
        if cart_count:
            # 類加購物車中商品的數據
            count += int(cart_count)
        if count > sku.stock:
            return JsonResponse({'res': 4, 'errmsg': '商品庫存不足'})

        conn.hset(cart_key, sku_id, count)

        total_count = conn.hlen(cart_key)

        # 4.返回應答
        return JsonResponse({'res': 5, 'total_count': total_count, 'msg': '添加成功'})


class CartInfoView(LoginRequiredMixin, View):
    '''購物車頁面顯示'''

    def get(self, request):
        '''獲取用戶購物車中商品的信息'''
        user = request.user
        conn = get_redis_connection('default')
        cart_key = 'cart_%d' % user.id

        cart_dict = conn.hgetall(cart_key)
        skus = []
        total_count = 0
        total_price = 0
        for sku_id, count in cart_dict.items():
            sku = GoodsSKU.objects.get(id=sku_id)
            amount = sku.price * int(count)
            sku.amount = amount
            sku.count = int(count)
            skus.append(sku)

            total_count += int(count)
            total_price += amount
        context = {'skus': skus, 'total_count': total_count, 'total_price': total_price}

        return render(request, 'cart.html', context)


class CartUpdateView(View):
    '''購物車記錄'''

    def post(self, request):
        '''購物車記錄更新'''
        # 接收數據
        user = request.user
        if not user.is_authenticated:
            return JsonResponse({'res': 0, 'errmsg': '請先登錄'})

        # 數據校驗
        sku_id = request.POST.get('sku_id')
        count = request.POST.get('count')

        if not all([sku_id, count]):
            return JsonResponse({'res': 1, 'errmsg': '数据不完整'})

        try:
            count = int(count)
        except Exception as e:
            return JsonResponse({'res': 2, 'errmsg': '商品數目出錯'})

        try:
            sku = GoodsSKU.objects.get(id=sku_id)
        except GoodsSKU.DoesNotExist:
            return JsonResponse({'res': 3, 'errmsg': '商品不存在'})

        # 業務處理
        conn = get_redis_connection('default')
        cart_key = 'cart_%d' % user.id

        if count > sku.stock:
            return JsonResponse({'res': 4, 'errmsg': '商品库存不足'})

        conn.hset(cart_key, sku_id, count)

        # 计算用户购物车中商品的总件数
        total_count = 0
        vals = conn.hvals(cart_key)
        for val in vals:
            print(val)
            total_count += int(val)
        # 返回應答
        return JsonResponse({'res': 5, 'message': '更新成功', 'total_count': total_count})


class CartDeleteView(View):
    '''购物车记录删除'''

    def post(self, request):
        user = request.user
        if not user.is_authenticated:
            return JsonResponse({'res': 0, 'errmsg': '請先登錄'})

        sku_id = request.POST.get('sku_id')

        if not sku_id:
            return JsonResponse({'res': 1, 'errmsg': '无效的商品id'})

        try:
            sku = GoodsSKU.objects.get(id=sku_id)
        except GoodsSKU.DoesNotExist:
            return JsonResponse({'res': 2, 'errmsg': '商品不存在'})

        conn = get_redis_connection('default')

        cart_key = 'cart_%d' % user.id

        conn.hdel(cart_key, sku_id)

        total_count = 0
        vals = conn.hvals(cart_key)
        for val in vals:
            print(val)
            total_count += int(val)

        return JsonResponse({'res': 3, 'message': '删除成功', 'total_count': total_count})
