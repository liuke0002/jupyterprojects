from celery import Celery
Celery('celery_tasks.tasks',broker=' ')